<?php
$subject=isset($_POST["subject"]) ? $_POST["subject"] : '';
?>

<label for="subject">Subject:</label>
                <select name="subject" id="subject">
                    <?php
                    $q="select Name from Subject";
                    $res=mysqli_query($conn, $q);
                    if (mysqli_num_rows($res) == 0){
                        echo '<h2>Subjects not found!</h2>';
                    }
                    else {
                        while ($r=mysqli_fetch_row($res)){
                            echo '<option value="'.$r[0].'">'.$r[0].'</option>';
                        }
                        echo '<option value="other">Other</option>';
                    }
                    ?>
                </select>