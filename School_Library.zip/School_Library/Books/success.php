<!DOCTYPE html>
<html>
<head>
    <title>Success</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 40px;
        }
        h2 {
            color: green;
        }
    </style>
</head>
<body>
    <h2>Success!</h2>
    <p>Your lending was successfull.</p>
    <p>Thank you for using our library.</p>
    
    <a href="./Books.php">
        <button type="button">Back</button>
    </a>
    
</body>
</html>
