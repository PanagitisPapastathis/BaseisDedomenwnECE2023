<!DOCTYPE html>
<html lang = "en">

<head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>
        School Unit Administrator Add Book that doesn't exist in the Database Add Author
    </title>
    <link rel = "stylesheet" href = "css/styles.css">
    <link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel = "stylesheet" href = "bootstrap/css/bootstrap.min.css">
    

</head>
<body>
    <nav class="navbar navbar-light navbar-expand-md" id="nav-bar">
        <div id="navbar-div" class="container-fluid">
            <a class="navbar-brand" id="nav-bar-text">School Library - School Unit Administrator Add Book that doesn't exist in the Database Add Author</a>
            <a id="navbar-items" href="index.php">
                <i class="fa fa-home "></i> Landing
            </a>
        </div>
    </nav>
    <main>
        <?php
        include '../connection.php';
        $conn=OpenCon();
        session_start();
        if(!isset($_GET["isbn"])){
            echo "<h2>Error: isbn fail no english</h2>";
            return;
        }
        $isbn=$_GET['isbn'];
        ?>
        <?php 
        echo '<h2>ISBN:'.$isbn.'</h2>';
        ?>










<label for="new_author">Author:</label>
                <select name="authors" id="authors" multiple required>
                    <?php
                    $q="select Name from Author";
                    $res=mysqli_query($conn, $q);
                    if (mysqli_num_rows($res) == 0){
                        echo '<h2>Authors not found!</h2>';
                    }
                    else {
                        while ($r=mysqli_fetch_row($res)){
                            echo '<option value="'.$r[0].'">'.$r[0].'</option>';
                        }
                        echo '<option value="other">Other</option>';
                        echo '<option value="many">Many</option>';
                    }
                    ?>
                <!--<input type="text" name="new_author" id="new_auhtor" placeholder="Author" required>-->
                </select>


<?php
                if($author=="other"){
    }
    if ($author=="many"){
        $i=0;
        $bool=true;
        $auth=array();

        while($i<10 && $bool=true){
            $i++;
            echo '<form action="add_not_new_book.php?isbn='.$isbn.'" method="post">';
            echo '<label for="authors">Author:</label>';
                echo '<select name="authors[]" id="authors" multiple>';
                    $q="select Name from Author";
                    $res=mysqli_query($conn, $q);
                    if (mysqli_num_rows($res) == 0){
                        echo '<h2>Authors not found!</h2>';
                    }
                    else {
                        while ($r=mysqli_fetch_row($res)){
                            echo '<option value="'.$r[0].'">'.$r[0].'</option>';
                        }
                    }
                echo '</select>';
                echo '<button type="submit">Done</button>';
                $auth[$i]= isset($_POST["authors"])? $_POST["authors"] : '';
                if(isset($_POST["authors"])){
                    $q="insert into Author (Name) values ('$auth[$i]')";
                    if(mysqli_query($conn, $q)) {
                        echo '<h2>Insertion Successful</h2>';
                    }
                    $bool=false;

                }


        }
    }

    $author=isset($_POST["new_author"]) ? $_POST["new_author"] : '';
    ?>

