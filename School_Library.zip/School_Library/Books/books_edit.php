<!DOCTYPE html>
<html lang = "en">

<head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>
        School Unit Administrator Profile Update
    </title>
    <link rel = "stylesheet" href = "css/styles.css">
    <link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel = "stylesheet" href = "bootstrap/css/bootstrap.min.css">
    

</head>

<body>
    <nav class="navbar navbar-light navbar-expand-md" id="nav-bar">
        <div id="navbar-div" class="container-fluid">
            <a class="navbar-brand" id="nav-bar-text">School Library - School Unit Administrator Update</a>
            <a id="navbar-items" href="index.php">
                <i class="fa fa-home "></i> Landing
            </a>
        </div>
    </nav>
    <main>
        <form action="update_central_admin_profile.php" method="post">
            <p>
                <label for="new_image">New Image:</label>
                <input type="text" name="new_image" id="new_image" placeholder="New Image" >
                <br>
                <label for="new_key_words">New Key Words:</label>
                <input type="text" name="new_key_words" id="new_key_words" placeholder="New Key Words" >
                <br>
                <label for="new_summary">New Summary:</label>
                <input type="text" name="new_summary" id="new_summary" placeholder="New Summary" >
                <br>
                <label for="new_language">New Summary:</label>
                <input type="text" name="new_language" id="new_language" placeholder="New Language" >
                <br>
                <label for="new_author">New Author:</label>
                <input type="number" name="new_author" id="new_auhtor" placeholder="Author" required>
                <br>
                <label for="new_publisher">New Publisher:</label>
                <input type="text" name="new_publisher" id="new_publisher" placeholder="New Publisher" required>
                <br>
                <button type="submit">Done</button>
            </p>
        </form>
    </main>
    <?php
    include '../connection.php';
    $conn=OpenCon();
    session_start();
    $isbn=$_GET['isbn'];
    $image=$_POST["new_image"];
    $key_words=$_POST["new_key_words"];
    $summary=$_POST["new_summary"];
    $language=$_POST["new_language"];
    $author=$_POST["new_author"];
    $publisher=$_POST["new_publisher"];
    
        $query="update Books set Image='$image', Key Words='$key_words', Summary='$summary', Language ='$language', Author='$author', Publisher='$publisher' where ISBN='$isbn' ";
        if(mysqli_query($conn, $query)){
            $query1="update Author set Author='$author', where ISBN='$isbn' "; //book author + chech if autgor exists
            if(mysqli_query($conn, $query1)){
                if(mysqli_query($conn, $query1)){
                    $query1="update Publisher set Publisher='$publisher' where ISBN='$isbn' ";     //book publisher + check if publisher exists        
                    header("Location: ./central_admin_profile.php");
                    exit();
                }
                else{
                    echo "Error on Publisher update: <br>" .mysqli_error($conn)."<br>";
                }
            }
            else{
                echo "Error on Author update: <br>" .mysqli_error($conn)."<br>";
            }
        }
        else{
            echo "Error on Book update: <br>" .mysqli_error($conn)."<br>";
        }
    
    ?>
    </body>
</html>