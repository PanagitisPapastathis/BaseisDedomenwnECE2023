<!DOCTYPE html>
<html>
<head>
    <title>Lending Rules</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h2 {
            margin-bottom: 20px;
        }

        p {
            margin-bottom: 10px;
        }

        .button-container {
            margin-top: 20px;
        }

        .button-container button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .button-container button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2>Booking Rules</h2>
    <p>
        Blah blah blah... (Provide information about the booking rules here)
    </p>
    <p>
        More details... (Add additional information if needed)
    </p>
    <div class="button-container">
        <form method="post" action="booking.php">
            <button type="submit" name="book">Proceed to Booking</button>
        </form>
    </div>
    <a href="./book_info.php">
        <button type="button">Back</button>
    </a>
</body>
</html>
<?php
    // lend.php

    if (isset($_POST['book'])) {
        include '../connection.php';
        $conn = OpenCon();
        session_start();
        $username = $_SESSION["username"];
        $isbn = $_SESSION['ISBN'];
        
        $subquery = "select c.copy_id 
        from copies as c
        join users as u on c.School_Name  = u.School_Name 
        where c.ISBN = '$isbn'
        and u.Username = '$username'";
        
        $result=mysqli_query($conn, $subquery);
        
        
        if ($row = mysqli_fetch_assoc($result)) {
           $copy_id = $row['copy_id'];    
           $query = "insert into Booking(Username, Copy_id) values ('$username', $copy_id)" ; #!!!!!!!!!!
           {if (mysqli_query($conn, $query)) {
                header("Location: ./success.php");
                exit;
            } else {
            
                echo "Error: " . mysqli_error($conn);
            }
            }
        }

    }
?>
