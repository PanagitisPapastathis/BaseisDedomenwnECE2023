<!DOCTYPE html>
<html>
<head>
    <title>Backup</title>
</head>
<body>
    <h1 style="color: red;">DANGER ZONE!!!</h1>
    <a href="create_backup.php"><button>Create Backup</button></a>
    <a href="revert_to_backup.php"><button>Revert to Backup</button></a><br><br>
    <a href="../home.php"><button>Back</button></a>
</body>
</html>