<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
</head>
<body>
<h2> Login Page </h2>
<p>
    <form method="post" action="login.php">
    <input type="text" name="username" placeholder="Username" required><br><br>
    <input type="password" name="password" placeholder="Password" required><br><br>
    <input type="submit" value="Login"> <br> <br>
    <?php
        include 'connection.php';
        if (isset($_POST["username"])&&isset($_POST["password"])) {
            $conn = OpenCon();
            $username = $_POST["username"];
            $password = $_POST["password"];
            session_start();
            $query = "SELECT * FROM Users WHERE username = '$username'";
            $result = mysqli_query($conn, $query);
            if ($row = mysqli_fetch_assoc($result)) {
                $storedPassword = $row['Password'];
                $status = $row['Status'];
                if ($password == $storedPassword) {
                    $_SESSION["username"] = $username;
                    $_SESSION["school_name"]= $row['School_Name'];
                    $_SESSION["status"] = $row['Status'];
                    switch ($status) {
                        case 'Student':
                            header("Location: ./Student/student.php");
                            break;
                        case 'Teacher':
                            header("Location: ./Teacher/teacher.php");
                            break;
                        case 'Admin':
                            header("Location: ./Admin/admin.php");
                            break;
                        case 'Central Admin':
                            header("Location: ./Central_admin/central_admin.php");
                            break;
                        default:
                            echo "Invalid user status.";
                    }
                    exit; //exit after redirecting
                }
                else {
                    echo "Incorrect password.";
                }
            }
            else {
                echo "User does not exist.";
            }
            $conn -> close();
        }
    ?>
</form>
</p>
    <?php if(isset($error)) { echo $error; } ?>
</body>
</html>
