SELECT a.Name, COUNT(ba.ISBN) AS num_books FROM Author a JOIN Book_Author ba
ON a.Author_id = ba.Author_id
GROUP BY a.Author_id
HAVING num_books >= (SELECT MAX(num_books) - 5 FROM (
    SELECT COUNT(ba.ISBN) AS num_books
    FROM Book_Author ba
    GROUP BY ba.Author_id) subquery)
ORDER BY num_books DESC;